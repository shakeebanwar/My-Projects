﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;
namespace school_managment_system
{
    public partial class student_attendence : Form
    {
        public student_attendence()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");
        SqlCommand command;
        public int id;


        private void view()
        {
            SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("select * from s_attendence", con);
            DataTable dt = new DataTable();
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            con.Close();



        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            ATTENDENCE A = new ATTENDENCE();
            this.Hide();
            A.Show(); 
        }

        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "select * from student_enroll where S_ID=" + bunifuMetroTextbox1.Text;
                if (con.State != ConnectionState.Open)
                    con.Open();
                command = new SqlCommand(sql, con);
                SqlDataReader reader = command.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    bunifuMetroTextbox2.Text = reader[1].ToString();
                    bunifuMetroTextbox3.Text = reader[4].ToString();
                  



                    byte[] img = (byte[])(reader[7]);
                    if (img == null)
                        pictureBox1.Image = null;
                    else
                    {
                        MemoryStream ms = new MemoryStream(img);
                        pictureBox1.Image = Image.FromStream(ms);
                    }
                }
                else
                {
                    MessageBox.Show("This id not exist");
                    bunifuMetroTextbox2.Text = "";
                    bunifuMetroTextbox3.Text = "";
                  


                    pictureBox1.Image = null;

                }
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void bunifuThinButton25_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("insert into s_attendence(t_id,s_id, sname, sclass,date,status) values('" + bunifuMetroTextbox4.Text + "','" + bunifuMetroTextbox1.Text + "','" + bunifuMetroTextbox2.Text + "','" + bunifuMetroTextbox3.Text + "','" + bunifuDatepicker1.Value + "','" + comboBox1.SelectedItem.ToString() + "')", con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("record insert");
                con.Close();
                view();
                bunifuMetroTextbox1.Text = "";
                bunifuMetroTextbox2.Text = "";
                bunifuMetroTextbox3.Text = "";
                bunifuMetroTextbox4.Text = "";


                comboBox1.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            view();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());

            bunifuMetroTextbox1.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            bunifuMetroTextbox2.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();

            bunifuMetroTextbox3.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            bunifuMetroTextbox4.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
          
            comboBox1.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
           
        
        }

        private void bunifuThinButton26_Click(object sender, EventArgs e)
        {
            if (id > 0)
            {

            
                SqlCommand cmd = new SqlCommand("Delete from s_attendence where t_id=@id", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@id", this.id);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record delete");
                view();

            }
            else
            {
                MessageBox.Show("select row first");
            }
        }

        private void bunifuThinButton24_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("update s_attendence set s_id='" + bunifuMetroTextbox1.Text + "',sname='" + bunifuMetroTextbox2.Text + "' , sclass='" + bunifuMetroTextbox3.Text + "' , status='" + comboBox1.Text + "'where t_id=@id", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ID", this.id);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record update");
                view();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void bunifuMetroTextbox4_OnValueChanged(object sender, EventArgs e)
        {

        }
    }
}
