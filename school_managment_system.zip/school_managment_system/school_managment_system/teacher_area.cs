﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.IO;

namespace school_managment_system
{
    public partial class teacher_area : Form
    {
        public teacher_area()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");
        SqlCommand command;
        private void view()
        {
            SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("select * from student_enroll", con);
            DataTable dt = new DataTable();
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            con.Close();



        }
        private void view1()
        {
            SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("select * from t_attendence where t_id="+bunifuMetroTextbox4.Text, con);
            DataTable dt = new DataTable();
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            con.Close();



        }
        private void view2()
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");

                SqlCommand cmd = new SqlCommand("select * from s_attendence where s_id=" + bunifuMetroTextbox4.Text, con);
                DataTable dt = new DataTable();
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                dt.Load(dr);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }



        }
        private void view4()
        {
            SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("select * from course", con);
            DataTable dt = new DataTable();
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            con.Close();



        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void teacher_area_Load(object sender, EventArgs e)
        {

        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            view();
        }

        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "select * from student_enroll where s_id=" + bunifuMetroTextbox4.Text;
                if (con.State != ConnectionState.Open)
                    con.Open();
                command = new SqlCommand(sql, con);
                SqlDataReader reader = command.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {

                    bunifuMetroTextbox4.Text = reader[0].ToString();
                    bunifuMetroTextbox1.Text = reader[1].ToString();
                    bunifuMetroTextbox2.Text = reader[4].ToString();




                    byte[] img = (byte[])(reader[7]);
                    if (img == null)
                        pictureBox1.Image = null;
                    else
                    {
                        MemoryStream ms = new MemoryStream(img);
                        pictureBox1.Image = Image.FromStream(ms);
                    }
                }
                else
                {
                    MessageBox.Show("This id not exist");
                    bunifuMetroTextbox4.Text = "";



                    pictureBox1.Image = null;

                }
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            view1();
        }

        private void bunifuThinButton24_Click(object sender, EventArgs e)
        {
            view2();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

            choice c = new choice();
            this.Hide();
            c.Show();

        }

        private void bunifuThinButton25_Click(object sender, EventArgs e)
        {
            class_schedule C = new class_schedule();
            this.Hide();
            C.Show();
        }

        private void bunifuThinButton26_Click(object sender, EventArgs e)
        {
            view4();
        }

        private void bunifuThinButton27_Click(object sender, EventArgs e)
        {
            EXAM E = new EXAM();
            this.Hide();
            E.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
