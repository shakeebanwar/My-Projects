﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.IO;
namespace school_managment_system
{
    public partial class FEE : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");

        public FEE()
        {
            InitializeComponent();
        }
        public int id;
        private void view()
        {
            SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("select * from FEE_INFO", con);
            DataTable dt = new DataTable();
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            con.Close();



        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand command;
                string sql = "select * from student_enroll where S_ID=" + bunifuMetroTextbox1.Text;
                if (con.State != ConnectionState.Open)
                    con.Open();
                command = new SqlCommand(sql, con);
                SqlDataReader reader = command.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    bunifuMetroTextbox2.Text = reader[1].ToString();
                    bunifuMetroTextbox3.Text = reader[4].ToString();
                   
                
                   



                    byte[] img = (byte[])(reader[7]);
                    if (img == null)
                        pictureBox2.Image = null;
                    else
                    {
                        MemoryStream ms = new MemoryStream(img);
                        pictureBox2.Image = Image.FromStream(ms);
                    }
                }
                else
                {
                    MessageBox.Show("This id not exist");
                    bunifuMetroTextbox2.Text = "";
                    bunifuMetroTextbox3.Text = "";
                    bunifuMetroTextbox4.Text = "";
                    bunifuMetroTextbox5.Text = "";
                    bunifuMetroTextbox6.Text = "";
                    


                    pictureBox1.Image = null;

                }
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void bunifuThinButton25_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("update FEE_INFO set STUDENT_Name='" + bunifuMetroTextbox2.Text + "' , STUDENT_CLASS='" + bunifuMetroTextbox3.Text + "' , MONTH='" + bunifuMetroTextbox4.Text + "', AMOUNT_PAID='" + bunifuMetroTextbox5.Text + "', AMOUNT_DUE='" + bunifuMetroTextbox6.Text + "' where FEE_ID=@id", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ID", this.id);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record update");
                view();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("insert into FEE_INFO values('" + bunifuMetroTextbox7.Text + "','" + bunifuMetroTextbox2.Text + "','" + bunifuMetroTextbox3.Text + "','" + bunifuMetroTextbox4.Text + "','" + bunifuMetroTextbox5.Text + "','" + bunifuMetroTextbox6.Text + "','" + bunifuMetroTextbox1.Text + "')", con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("record insert");
                con.Close();
                bunifuMetroTextbox1.Text = "";
                bunifuMetroTextbox2.Text = "";
                bunifuMetroTextbox3.Text = "";
                bunifuMetroTextbox4.Text = "";
                bunifuMetroTextbox5.Text = "";
                bunifuMetroTextbox6.Text = "";
                view();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void bunifuThinButton24_Click(object sender, EventArgs e)
        {
            view();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());

            bunifuMetroTextbox6.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            bunifuMetroTextbox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();

            bunifuMetroTextbox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            bunifuMetroTextbox4.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            bunifuMetroTextbox5.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            bunifuMetroTextbox6.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
           
            bunifuMetroTextbox1.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();

            bunifuMetroTextbox7.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
        }

        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
            if (id > 0)
            {

                SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("Delete from FEE_INFO where FEE_ID=@id", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@id", this.id);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record delete");
                view();
            }
            else
            {
                MessageBox.Show("select row first");
            }

        }

        private void FEE_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Main_Dashboard M = new Main_Dashboard();
            this.Hide();
            M.Show();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label13_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
