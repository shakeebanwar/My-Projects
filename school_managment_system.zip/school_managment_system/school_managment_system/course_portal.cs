﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;

namespace school_managment_system
{
    public partial class course_portal : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");
     
        public course_portal()
        {
            InitializeComponent();
        }
        public int id;
        public void fill_dd()
        {

            comboBox2.Items.Clear();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select T_name from Teacher_enroll";
            con.Open();
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                comboBox2.Items.Add(dr["T_name"].ToString());
            }
            con.Close();
        }
        private void view()
        {
            SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("select * from course", con);
            DataTable dt = new DataTable();
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            con.Close();



        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void course_portal_Load(object sender, EventArgs e)
        {
          
            fill_dd();
        
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Main_Dashboard M = new Main_Dashboard();
            this.Hide();
            M.Show();
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("insert into course values('" + bunifuMetroTextbox1.Text + "','" + bunifuMetroTextbox2.Text + "','" + bunifuMetroTextbox3.Text + "','" + comboBox2.SelectedItem.ToString() + "')", con);
            con.Open(); 
            cmd.ExecuteNonQuery();
            MessageBox.Show("record insert");
            con.Close();
            view();
            bunifuMetroTextbox1.Text = "";
            bunifuMetroTextbox2.Text = "";
            bunifuMetroTextbox3.Text = "";
       
            comboBox2.Text = "";
            fill_dd();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            view();
        }

        private void bunifuThinButton25_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("update course set course_name='" + bunifuMetroTextbox2.Text + "' , course_credit_hours='" + bunifuMetroTextbox3.Text + "', course_teach='" + comboBox2.Text + "' where COURSE_ID=@id", con);
                con.Open();
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ID", this.id);


                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record update");
                view();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());

            bunifuMetroTextbox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            bunifuMetroTextbox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();

            bunifuMetroTextbox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            comboBox2.Text= dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
        }

        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
            if (id > 0)
            {

                SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("Delete from course where course_id=@id", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@id", this.id);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record delete");
                view();
            }
            else
            {
                MessageBox.Show("select row first");
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label13_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
