﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace school_managment_system
{
    public partial class Main_Dashboard : Form
    {
        public Main_Dashboard()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void STUDENT_PORTAL_Click(object sender, EventArgs e)
        {
            student_portal s = new student_portal();
            this.Hide();
            s.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Teacher_portal t = new Teacher_portal();
            this.Hide();
            t.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            choice c = new choice();
            this.Hide();
            c.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            choice c = new choice();
            this.Hide();
            c.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            course_portal c = new course_portal();
            this.Hide();
            c.Show();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            teacher_enroll t = new teacher_enroll();
            this.Hide();
            t.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            student_enroll s = new student_enroll();
            this.Hide();

            s.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FEE f = new FEE();
            this.Hide();
            f.Show();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            ATTENDENCE a = new ATTENDENCE();
            this.Hide();
            a.Show();

        }

        private void label6_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
