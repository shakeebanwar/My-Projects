﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace school_managment_system
{
    public partial class choice : Form
    {
        public choice()
        {
            InitializeComponent();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            Admin_Login A = new Admin_Login();
            this.Hide();
            A.Show();
                
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            Teacher_Login T = new Teacher_Login();
            this.Hide();
            T.Show();
        }

        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
            Student S = new Student();
            this.Hide();
            S.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
