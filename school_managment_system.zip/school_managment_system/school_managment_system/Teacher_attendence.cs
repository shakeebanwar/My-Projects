﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.IO;

namespace school_managment_system
{
    public partial class Teacher_attendence : Form
    {
        public Teacher_attendence()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");
        SqlCommand command;
        public int id;
        private void view()
        {
            SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("select * from t_attendence", con);
            DataTable dt = new DataTable();
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            con.Close();



        }
        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "select * from Teacher_enroll where T_ID=" + bunifuMetroTextbox1.Text;
                if (con.State != ConnectionState.Open)
                    con.Open();
                command = new SqlCommand(sql, con);
                SqlDataReader reader = command.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    bunifuMetroTextbox2.Text = reader[1].ToString();
                   
                    


                    byte[] img = (byte[])(reader[7]);
                    if (img == null)
                        pictureBox1.Image = null;
                    else
                    {
                        MemoryStream ms = new MemoryStream(img);
                        pictureBox1.Image = Image.FromStream(ms);
                    }
                }
                else
                {
                    MessageBox.Show("This id not exist");
                    bunifuMetroTextbox2.Text = "";
            
                  


                    pictureBox1.Image = null;

                }
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            ATTENDENCE A = new ATTENDENCE();
            this.Hide();
            A.Show(); 

        }

        private void bunifuThinButton25_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("insert into t_attendence(a_id,t_id, tname,date,status) values('" + bunifuMetroTextbox3.Text + "','" + bunifuMetroTextbox1.Text + "','" + bunifuMetroTextbox2.Text + "','" + bunifuDatepicker1.Value + "','" + comboBox1.SelectedItem.ToString() + "')", con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("record insert");
                con.Close();
                bunifuMetroTextbox1.Text = "";
                bunifuMetroTextbox2.Text = "";
                bunifuMetroTextbox3.Text = "";


                comboBox1.Text = "";
                view();
            }

            catch(Exception ex){
                MessageBox.Show(ex.Message);

            }
      
        }

        private void Teacher_attendence_Load(object sender, EventArgs e)
        {

        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            view();
        }

        private void bunifuThinButton24_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("update t_attendence set t_id='" + bunifuMetroTextbox1.Text + "',tname='" + bunifuMetroTextbox2.Text + "', status='" + comboBox1.Text + "'where a_id=@id", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ID", this.id);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record update");
                view();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());

            bunifuMetroTextbox1.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            bunifuMetroTextbox2.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();

            bunifuMetroTextbox3.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
     

            comboBox1.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
        }

        private void bunifuThinButton26_Click(object sender, EventArgs e)
        {

            try
            {
                if (id > 0)
                {

                    SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");
                    SqlCommand cmd = new SqlCommand("Delete from T_attendence where a_id=@id", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@id", this.id);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Record delete");
                    bunifuMetroTextbox1.Text = "";
                    bunifuMetroTextbox2.Text = "";
                    bunifuMetroTextbox3.Text = "";
                    comboBox1.Text = "";
                    bunifuDatepicker1.ResetText();
                    view();

                }
                else
                {
                    MessageBox.Show("select row first");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
