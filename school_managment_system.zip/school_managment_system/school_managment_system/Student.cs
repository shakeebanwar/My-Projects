﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace school_managment_system
{
    public partial class Student : Form
    {
        public Student()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            choice C = new choice();
            this.Hide();
            C.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            student_registration S = new student_registration();
            this.Hide();
            S.Show();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("SELECT * FROM  s_registration WHERE User_NAME='" + bunifuMetroTextbox2.Text + "'and password='" + bunifuMetroTextbox1.Text + "'", con);
            con.Open();
            
            DataTable d = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(d);
            
            if (d.Rows.Count == 1)
            {

    
                student_area s = new student_area();
                this.Hide();
                s.Show();
                MessageBox.Show("login sucessfully");
            }
            else
            {
                MessageBox.Show("login not sucessfully");
            }
            con.Close();
            bunifuMetroTextbox1.Text = "";
            bunifuMetroTextbox2.Text = "";
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
        }
    

