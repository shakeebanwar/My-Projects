﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;

namespace school_managment_system
{
    public partial class Teacher_portal : Form
    {
        public Teacher_portal()
        {
            InitializeComponent();
        }
        public int id;
        private void view()
        {
            SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("select * from t_registration", con);
            DataTable dt = new DataTable();
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            con.Close();



        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Main_Dashboard M = new Main_Dashboard();
            this.Hide();
            M.Show();
        }

        private void Teacher_portal_Load(object sender, EventArgs e)
        {
            
        }

        private void bunifuThinButton24_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("insert into t_registration values('" + bunifuMetroTextbox1.Text + "','" + bunifuMetroTextbox2.Text + "','" + bunifuMetroTextbox3.Text + "','" + bunifuMetroTextbox4.Text + "','" + bunifuMetroTextbox5.Text + "','" + bunifuMetroTextbox6.Text + "','" + bunifuMetroTextbox7.Text + "')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("record insert");
            con.Close();
            view();
            bunifuMetroTextbox1.Text = "";
            bunifuMetroTextbox2.Text = "";
            bunifuMetroTextbox3.Text = "";
            bunifuMetroTextbox4.Text = "";
            bunifuMetroTextbox5.Text = "";
            bunifuMetroTextbox6.Text = "";
            bunifuMetroTextbox7.Text = "";
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            view();
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("update t_registration set First_Name='" + bunifuMetroTextbox1.Text + "' , Last_Name='" + bunifuMetroTextbox2.Text + "' , User_Name='" + bunifuMetroTextbox3.Text + "', Password='" + bunifuMetroTextbox4.Text + "', Email='" + bunifuMetroTextbox5.Text + "', Contact='" + bunifuMetroTextbox6.Text + "', Designation='" + bunifuMetroTextbox7.Text + "' where ID=@id", con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@ID", this.id);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record update");
            view();

        }

        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
            if (id > 0)
            {

                SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("Delete from t_registration where id=@id", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@id", this.id);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record delete");
                view();

                bunifuMetroTextbox1.Text = "";
                bunifuMetroTextbox2.Text = "";
                bunifuMetroTextbox3.Text = "";
                bunifuMetroTextbox4.Text = "";
                bunifuMetroTextbox5.Text = "";
                bunifuMetroTextbox6.Text = "";
                bunifuMetroTextbox7.Text = "";
            }
            else
            {
                MessageBox.Show("select row first");
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[7].Value.ToString());

            bunifuMetroTextbox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            bunifuMetroTextbox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();

            bunifuMetroTextbox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            bunifuMetroTextbox4.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            bunifuMetroTextbox5.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            bunifuMetroTextbox6.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            bunifuMetroTextbox7.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
