﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace school_managment_system
{
    public partial class Admin_Login : Form
    {
        public Admin_Login()
        {
            InitializeComponent();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            
               
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
           
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Teacher_Registration r = new Teacher_Registration();
            this.Hide();
            r.Show();
                
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            choice C = new choice();
            this.Hide();
            C.Show();
        }

        private void bunifuThinButton21_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("SELECT * FROM  admin_login WHERE NAME='" +bunifuMetroTextbox2.Text + "'and password='" + bunifuMetroTextbox1.Text+ "'", con);
            con.Open();
            //cmd.ExecuteNonQuery();
            DataTable d = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(d);
            // int count = 0;
            //count = Convert.ToInt32(d.Rows.ToString());



            if (d.Rows.Count == 1)
            {

                Main_Dashboard m = new Main_Dashboard();
                this.Hide();
               m.Show();
                
            }
            else
            {
                MessageBox.Show("login not sucessfully");
            }
            con.Close();
        }

        private void Admin_Login_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        }
    }

