﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace school_managment_system
{
    public partial class student_area : Form
    {
        public student_area()
        {
            InitializeComponent();
        }
        private void view4()
        {
            SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("select * from course", con);
            DataTable dt = new DataTable();
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            con.Close();



        }
        private void view1()
        {
            SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("select * from S_attendence where s_id=" + bunifuMetroTextbox4.Text, con);
            DataTable dt = new DataTable();
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            con.Close();



        }
        private void view2()
        {
            SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=school managment system;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("select * from FEE_INFO where s_id=" + bunifuMetroTextbox4.Text, con);
            DataTable dt = new DataTable();
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            con.Close();



        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void bunifuThinButton26_Click(object sender, EventArgs e)
        {
            view4();
        }

        private void bunifuThinButton27_Click(object sender, EventArgs e)
        {
            exam1 e1 = new exam1();
            this.Hide();
            e1.Show();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            class_schedule1 c = new class_schedule1();
            this.Hide();
            c.Show();
        }

        private void student_area_Load(object sender, EventArgs e)
        {

        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            view1();
        }

        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
            view2();
                
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            choice c = new choice();
            this.Hide();
            c.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
